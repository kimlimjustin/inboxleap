import json
import os
import boto3
import urllib3
from email.parser import Parser

s3_client = boto3.client('s3')
http = urllib3.PoolManager()

BUCKET = os.environ.get('EMAIL_BUCKET')
PREFIX = os.environ.get('EMAIL_PREFIX', '')
DOMAIN_NAME = os.environ.get('DOMAIN_NAME')
BACKEND_URL = os.environ.get('BACKEND_URL', 'https://inboxleap.com')
WEBHOOK_SECRET = os.environ.get('WEBHOOK_SECRET', 'your-webhook-secret')

def parse_email_content(raw_email):
    """Parse raw email content and extract structured data"""
    try:
        parser = Parser()
        parsed_email = parser.parsestr(raw_email)
        
        # Extract basic headers
        subject = parsed_email.get('Subject', 'No Subject')
        from_addr = parsed_email.get('From', '')
        to_addrs = parsed_email.get('To', '').split(',') if parsed_email.get('To') else []
        cc_addrs = parsed_email.get('Cc', '').split(',') if parsed_email.get('Cc') else []
        bcc_addrs = parsed_email.get('Bcc', '').split(',') if parsed_email.get('Bcc') else []
        date_header = parsed_email.get('Date', '')
        
        # Clean up addresses
        to_addrs = [addr.strip() for addr in to_addrs if addr.strip()]
        cc_addrs = [addr.strip() for addr in cc_addrs if addr.strip()]
        bcc_addrs = [addr.strip() for addr in bcc_addrs if addr.strip()]
        
        # Extract body content
        body = ""
        if parsed_email.is_multipart():
            for part in parsed_email.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True).decode('utf-8', errors='replace')
                    break
                elif part.get_content_type() == "text/html" and not body:
                    body = part.get_payload(decode=True).decode('utf-8', errors='replace')
        else:
            body = parsed_email.get_payload(decode=True).decode('utf-8', errors='replace')
        
        # Extract thread headers
        headers = {
            'in-reply-to': parsed_email.get('In-Reply-To'),
            'references': parsed_email.get('References'),
            'message-id': parsed_email.get('Message-ID')
        }
        
        return {
            'subject': subject,
            'from': from_addr,
            'to': to_addrs,
            'cc': cc_addrs,
            'bcc': bcc_addrs,
            'body': body,
            'date': date_header,
            'headers': headers
        }
    except Exception as e:
        print(f"Error parsing email: {e}")
        return None

def send_to_backend(email_data, message_id):
    """Send parsed email data to backend webhook"""
    try:
        payload = {
            'messageId': message_id,
            'subject': email_data['subject'],
            'from': email_data['from'],
            'to': email_data['to'],
            'cc': email_data['cc'],
            'bcc': email_data['bcc'],
            'body': email_data['body'],
            'date': email_data['date'],
            'headers': email_data['headers']
        }
        
        webhook_url = f"{BACKEND_URL}/api/inbound/email"
        
        response = http.request(
            'POST',
            webhook_url,
            body=json.dumps(payload).encode('utf-8'),
            headers={
                'Content-Type': 'application/json',
                'X-Auth-Token': WEBHOOK_SECRET
            },
            timeout=30
        )
        
        if response.status == 200:
            print(f"Successfully sent email to backend: {message_id}")
            return True
        else:
            print(f"Backend returned status {response.status}: {response.data.decode('utf-8', errors='replace')}")
            return False
            
    except Exception as e:
        print(f"Error sending to backend: {e}")
        return False

def handler(event, context):
    # Log the entire event for troubleshooting
    print('SES event:', json.dumps(event))

    # Get the message from the SES event
    ses_mail = event['Records'][0]['ses']['mail']
    message_id = ses_mail['messageId']

    # Parse recipients to get all destinations
    destinations = ses_mail.get('destination', [])

    # Read stored email from S3 and send to backend webhook
    try:
        s3_key = f"{PREFIX}{message_id}"
        obj = s3_client.get_object(Bucket=BUCKET, Key=s3_key)
        raw_email = obj['Body'].read().decode('utf-8', errors='replace')
        print(f"Fetched email from s3://{BUCKET}/{s3_key}, size={len(raw_email)} bytes")
        
        # Parse email content
        email_data = parse_email_content(raw_email)
        if email_data:
            # Send to backend for processing
            backend_success = send_to_backend(email_data, message_id)
            print(f"Backend webhook: {'Success' if backend_success else 'Failed'}")
        else:
            print("Failed to parse email content")
            
    except Exception as e:
        print(f"Failed to fetch/process email from S3: {e}")

    # Note: Auto-reply functionality removed - backend handles replies via Postmark

    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Email processed and sent to backend webhook',
            'messageId': message_id,
            'recipients': destinations,
            's3Key': f"{PREFIX}{message_id}",
        })
    }
